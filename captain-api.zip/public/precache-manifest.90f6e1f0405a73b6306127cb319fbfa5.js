self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5de23be7d15d40dfceaab2ef45b6d8c0",
    "url": "/index.html"
  },
  {
    "revision": "d178a3491ddc0e0a03cf",
    "url": "/static/js/5.3b4af5fd.chunk.js"
  },
  {
    "revision": "81dfab18a323d46805a4",
    "url": "/static/js/Home.9b1cb2fa.chunk.js"
  },
  {
    "revision": "48e173493179789756d1",
    "url": "/static/js/Login.4db807ef.chunk.js"
  },
  {
    "revision": "3a516559b12ae12875c8",
    "url": "/static/js/Settings.8875af11.chunk.js"
  },
  {
    "revision": "984027d96e49b28c0393",
    "url": "/static/js/main.847678ec.chunk.js"
  },
  {
    "revision": "9e17ef1524acc5cd362a",
    "url": "/static/js/runtime~main.c32b26c2.js"
  }
]);